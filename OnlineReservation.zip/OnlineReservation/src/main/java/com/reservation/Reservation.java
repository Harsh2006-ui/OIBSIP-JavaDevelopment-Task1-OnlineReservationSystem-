package com.reservation;

/** One booking row from the reservations table. */
public class Reservation {
    public final String pnr;
    public final String username;
    public final String passengerName;
    public final int trainNo;
    public final String trainName;
    public final String classType;
    public final String journeyDate;
    public final String source;
    public final String destination;
    public final String bookedAt;

    public Reservation(String pnr, String username, String passengerName, int trainNo,
                       String trainName, String classType, String journeyDate,
                       String source, String destination, String bookedAt) {
        this.pnr = pnr;
        this.username = username;
        this.passengerName = passengerName;
        this.trainNo = trainNo;
        this.trainName = trainName;
        this.classType = classType;
        this.journeyDate = journeyDate;
        this.source = source;
        this.destination = destination;
        this.bookedAt = bookedAt;
    }

    public String details() {
        return "PNR            : " + pnr + "\n"
                + "Passenger      : " + passengerName + "\n"
                + "Train          : " + trainNo + " - " + trainName + "\n"
                + "Class          : " + classType + "\n"
                + "Date of journey: " + journeyDate + "\n"
                + "From           : " + source + "\n"
                + "To             : " + destination + "\n"
                + "Booked at      : " + bookedAt;
    }
}
