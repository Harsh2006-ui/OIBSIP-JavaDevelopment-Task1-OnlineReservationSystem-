package com.reservation;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/** Opens connections, creates the tables on first run and inserts demo data. */
public final class Database {
    // The file reservation.db is created in the folder the program is started from.
    private static final String URL = "jdbc:sqlite:reservation.db";

    private Database() {
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL);
    }

    public static void init() throws SQLException {
        try (Connection c = getConnection(); Statement st = c.createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS users ("
                    + "username TEXT PRIMARY KEY, password_hash TEXT NOT NULL)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS trains ("
                    + "train_no INTEGER PRIMARY KEY, train_name TEXT NOT NULL)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS reservations ("
                    + "pnr TEXT PRIMARY KEY, username TEXT NOT NULL, passenger_name TEXT NOT NULL, "
                    + "train_no INTEGER NOT NULL, train_name TEXT NOT NULL, class_type TEXT NOT NULL, "
                    + "journey_date TEXT NOT NULL, source TEXT NOT NULL, destination TEXT NOT NULL, "
                    + "booked_at TEXT NOT NULL)");
        }
        seed();
    }

    private static void seed() throws SQLException {
        try (Connection c = getConnection()) {
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT OR IGNORE INTO users (username, password_hash) VALUES (?, ?)")) {
                addUser(ps, "admin", "admin123");
                addUser(ps, "student", "pass123");
            }
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT OR IGNORE INTO trains (train_no, train_name) VALUES (?, ?)")) {
                addTrain(ps, 12627, "Karnataka Express");
                addTrain(ps, 12301, "Howrah Rajdhani Express");
                addTrain(ps, 12951, "Mumbai Rajdhani Express");
                addTrain(ps, 12009, "Shatabdi Express");
                addTrain(ps, 12723, "Telangana Express");
                addTrain(ps, 22691, "Bengaluru Rajdhani Express");
                addTrain(ps, 12839, "Chennai Mail");
                addTrain(ps, 12615, "Grand Trunk Express");
            }
        }
    }

    private static void addUser(PreparedStatement ps, String user, String pass) throws SQLException {
        ps.setString(1, user);
        ps.setString(2, hash(pass));
        ps.executeUpdate();
    }

    private static void addTrain(PreparedStatement ps, int no, String name) throws SQLException {
        ps.setInt(1, no);
        ps.setString(2, name);
        ps.executeUpdate();
    }

    /** SHA-256 hex digest so plain-text passwords are never stored. */
    public static String hash(String text) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(text.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
