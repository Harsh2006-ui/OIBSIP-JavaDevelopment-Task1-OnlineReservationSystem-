package com.reservation;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;

public class LoginFrame extends JFrame {
    private final JTextField userField = new JTextField(16);
    private final JPasswordField passField = new JPasswordField(16);
    private final ReservationDAO dao = new ReservationDAO();

    public LoginFrame() {
        super("Online Reservation System - Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(24, 32, 24, 32));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 6, 6, 6);

        JLabel title = new JLabel("Train Reservation Login");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 18f));
        g.gridx = 0;
        g.gridy = 0;
        g.gridwidth = 2;
        form.add(title, g);

        g.gridwidth = 1;
        g.anchor = GridBagConstraints.WEST;
        g.gridy = 1;
        form.add(new JLabel("Username"), g);
        g.gridx = 1;
        form.add(userField, g);

        g.gridx = 0;
        g.gridy = 2;
        form.add(new JLabel("Password"), g);
        g.gridx = 1;
        form.add(passField, g);

        JButton login = new JButton("Login");
        g.gridx = 0;
        g.gridy = 3;
        g.gridwidth = 2;
        g.anchor = GridBagConstraints.CENTER;
        form.add(login, g);

        JLabel hint = new JLabel("Demo account: student / pass123");
        hint.setForeground(java.awt.Color.GRAY);
        g.gridy = 4;
        form.add(hint, g);

        login.addActionListener(e -> doLogin());
        getRootPane().setDefaultButton(login); // Enter key submits

        setContentPane(form);
        pack();
        setResizable(false);
        setLocationRelativeTo(null);
    }

    private void doLogin() {
        String user = userField.getText().trim();
        String pass = new String(passField.getPassword());
        if (user.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter both username and password.",
                    "Missing details", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            if (dao.authenticate(user, pass)) {
                dispose();
                new MainFrame(user).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Access denied: invalid username or password.",
                        "Login failed", JOptionPane.ERROR_MESSAGE);
                passField.setText("");
                passField.requestFocusInWindow();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
