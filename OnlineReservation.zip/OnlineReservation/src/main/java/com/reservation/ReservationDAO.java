package com.reservation;

import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** All SQL lives here. Every query uses PreparedStatement to prevent SQL injection. */
public class ReservationDAO {
    private static final SecureRandom RANDOM = new SecureRandom();

    public boolean authenticate(String username, String password) throws SQLException {
        String sql = "SELECT 1 FROM users WHERE username = ? AND password_hash = ?";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, Database.hash(password));
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /** Returns the train name, or null when the train number does not exist. */
    public String findTrainName(int trainNo) throws SQLException {
        String sql = "SELECT train_name FROM trains WHERE train_no = ?";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, trainNo);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString(1) : null;
            }
        }
    }

    /** Saves a booking with a new unique PNR and returns it. */
    public Reservation book(String username, String passenger, int trainNo, String trainName,
                            String classType, String date, String source, String destination)
            throws SQLException {
        String bookedAt = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        String sql = "INSERT INTO reservations (pnr, username, passenger_name, train_no, train_name, "
                + "class_type, journey_date, source, destination, booked_at) VALUES (?,?,?,?,?,?,?,?,?,?)";
        try (Connection c = Database.getConnection()) {
            String pnr;
            do {
                pnr = newPnr();
            } while (exists(c, pnr));
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setString(1, pnr);
                ps.setString(2, username);
                ps.setString(3, passenger);
                ps.setInt(4, trainNo);
                ps.setString(5, trainName);
                ps.setString(6, classType);
                ps.setString(7, date);
                ps.setString(8, source);
                ps.setString(9, destination);
                ps.setString(10, bookedAt);
                ps.executeUpdate();
            }
            return new Reservation(pnr, username, passenger, trainNo, trainName, classType,
                    date, source, destination, bookedAt);
        }
    }

    /** Returns the booking for a PNR, or null if none exists. */
    public Reservation findByPnr(String pnr) throws SQLException {
        String sql = "SELECT * FROM reservations WHERE pnr = ?";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, pnr);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return null;
                }
                return new Reservation(rs.getString("pnr"), rs.getString("username"),
                        rs.getString("passenger_name"), rs.getInt("train_no"),
                        rs.getString("train_name"), rs.getString("class_type"),
                        rs.getString("journey_date"), rs.getString("source"),
                        rs.getString("destination"), rs.getString("booked_at"));
            }
        }
    }

    public boolean cancel(String pnr) throws SQLException {
        String sql = "DELETE FROM reservations WHERE pnr = ?";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, pnr);
            return ps.executeUpdate() > 0;
        }
    }

    private boolean exists(Connection c, String pnr) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("SELECT 1 FROM reservations WHERE pnr = ?")) {
            ps.setString(1, pnr);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /** 10-digit number, never starting with 0. */
    private String newPnr() {
        long n = 1_000_000_000L + (long) (RANDOM.nextDouble() * 9_000_000_000L);
        return Long.toString(n);
    }
}
