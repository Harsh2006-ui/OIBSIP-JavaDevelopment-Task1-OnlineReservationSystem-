package com.reservation;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.FlowLayout;
import java.sql.SQLException;

public class CancelPanel extends JPanel {
    private final ReservationDAO dao;
    private final JTextField pnrField = new JTextField(14);
    private final JTextArea details = new JTextArea(9, 38);
    private final JButton cancelButton = new JButton("Confirm Cancellation");
    private Reservation current; // the booking currently shown, or null

    public CancelPanel(ReservationDAO dao) {
        this.dao = dao;
        setLayout(new BorderLayout(0, 12));
        setBorder(BorderFactory.createEmptyBorder(16, 24, 16, 24));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        top.add(new JLabel("PNR number"));
        top.add(pnrField);
        JButton fetch = new JButton("Fetch");
        top.add(fetch);
        add(top, BorderLayout.NORTH);

        details.setEditable(false);
        details.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        details.setText("Enter a PNR and press Fetch to see the booking.");
        add(new JScrollPane(details), BorderLayout.CENTER);

        cancelButton.setEnabled(false);
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottom.add(cancelButton);
        add(bottom, BorderLayout.SOUTH);

        fetch.addActionListener(e -> doFetch());
        pnrField.addActionListener(e -> doFetch());
        cancelButton.addActionListener(e -> doCancel());
    }

    private void doFetch() {
        String pnr = pnrField.getText().trim();
        current = null;
        cancelButton.setEnabled(false);
        if (pnr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a PNR number.",
                    "Invalid input", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!pnr.matches("\\d{10}")) {
            JOptionPane.showMessageDialog(this, "A PNR is a 10-digit number.",
                    "Invalid input", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            Reservation r = dao.findByPnr(pnr);
            if (r == null) {
                details.setText("No booking found for PNR " + pnr + ".");
                return;
            }
            current = r;
            details.setText(r.details());
            cancelButton.setEnabled(true);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void doCancel() {
        if (current == null) {
            return;
        }
        int choice = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to cancel PNR " + current.pnr + "?",
                "Confirm cancellation", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (choice != JOptionPane.YES_OPTION) {
            return;
        }
        try {
            if (dao.cancel(current.pnr)) {
                JOptionPane.showMessageDialog(this, "Booking " + current.pnr + " has been cancelled.",
                        "Cancelled", JOptionPane.INFORMATION_MESSAGE);
                details.setText("Booking cancelled.");
                pnrField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "That booking no longer exists.",
                        "Not found", JOptionPane.WARNING_MESSAGE);
            }
            current = null;
            cancelButton.setEnabled(false);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
