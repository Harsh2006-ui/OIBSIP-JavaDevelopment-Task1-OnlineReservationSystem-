package com.reservation;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class BookingPanel extends JPanel {
    private static final String[] CLASSES = {"Sleeper (SL)", "Third AC (3A)", "Second AC (2A)",
            "First AC (1A)", "Chair Car (CC)"};

    private final ReservationDAO dao;
    private final String username;

    private final JTextField passengerField = new JTextField(20);
    private final JTextField trainNoField = new JTextField(20);
    private final JTextField trainNameField = new JTextField(20);
    private final JComboBox<String> classBox = new JComboBox<>(CLASSES);
    private final JTextField dateField = new JTextField(20);
    private final JTextField sourceField = new JTextField(20);
    private final JTextField destField = new JTextField(20);

    public BookingPanel(ReservationDAO dao, String username) {
        this.dao = dao;
        this.username = username;
        setLayout(new GridBagLayout());
        setBorder(BorderFactory.createEmptyBorder(16, 24, 16, 24));

        trainNameField.setEditable(false); // filled in automatically from the train number
        dateField.setToolTipText("Format: yyyy-MM-dd, for example 2026-11-05");

        addRow(0, "Passenger name", passengerField);
        addRow(1, "Train number", trainNoField);
        addRow(2, "Train name (auto)", trainNameField);
        addRow(3, "Class type", classBox);
        addRow(4, "Date of journey (yyyy-MM-dd)", dateField);
        addRow(5, "From (source station)", sourceField);
        addRow(6, "To (destination station)", destField);

        JButton book = new JButton("Book Ticket");
        JButton clear = new JButton("Clear");
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        buttons.add(book);
        buttons.add(clear);
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0;
        g.gridy = 7;
        g.gridwidth = 2;
        g.insets = new Insets(16, 6, 6, 6);
        add(buttons, g);

        trainNoField.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) {
                lookupTrain();
            }

            public void removeUpdate(DocumentEvent e) {
                lookupTrain();
            }

            public void changedUpdate(DocumentEvent e) {
                lookupTrain();
            }
        });
        book.addActionListener(e -> doBook());
        clear.addActionListener(e -> clearForm());
    }

    private void addRow(int row, String label, JComponent field) {
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 6, 6, 6);
        g.gridy = row;
        g.gridx = 0;
        g.anchor = GridBagConstraints.WEST;
        add(new JLabel(label), g);
        g.gridx = 1;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.weightx = 1;
        add(field, g);
    }

    private void lookupTrain() {
        String text = trainNoField.getText().trim();
        trainNameField.setText("");
        if (!text.matches("\\d{1,9}")) {
            return;
        }
        try {
            String name = dao.findTrainName(Integer.parseInt(text));
            trainNameField.setText(name == null ? "Train not found" : name);
        } catch (SQLException ex) {
            trainNameField.setText("Database error");
        }
    }

    private void doBook() {
        String passenger = passengerField.getText().trim();
        String trainText = trainNoField.getText().trim();
        String dateText = dateField.getText().trim();
        String source = sourceField.getText().trim();
        String dest = destField.getText().trim();

        String error = validate(passenger, trainText, dateText, source, dest);
        if (error != null) {
            JOptionPane.showMessageDialog(this, error, "Invalid input", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            int trainNo = Integer.parseInt(trainText);
            String trainName = dao.findTrainName(trainNo);
            if (trainName == null) {
                JOptionPane.showMessageDialog(this, "No train exists with number " + trainNo + ".",
                        "Invalid input", JOptionPane.WARNING_MESSAGE);
                return;
            }
            Reservation r = dao.book(username, passenger, trainNo, trainName,
                    (String) classBox.getSelectedItem(), dateText, source, dest);
            JOptionPane.showMessageDialog(this,
                    "Booking confirmed!\n\n" + r.details() + "\n\nKeep your PNR to cancel later.",
                    "Booking confirmation", JOptionPane.INFORMATION_MESSAGE);
            clearForm();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Could not save booking: " + ex.getMessage(),
                    "Database error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /** Returns an error message, or null when everything is valid. */
    private String validate(String passenger, String trainText, String dateText,
                            String source, String dest) {
        if (passenger.isEmpty() || trainText.isEmpty() || dateText.isEmpty()
                || source.isEmpty() || dest.isEmpty()) {
            return "Please fill in all the fields.";
        }
        if (!trainText.matches("\\d{1,9}")) {
            return "Train number must contain digits only.";
        }
        LocalDate date;
        try {
            date = LocalDate.parse(dateText); // strict yyyy-MM-dd
        } catch (DateTimeParseException ex) {
            return "Date must be a real date in yyyy-MM-dd format, for example 2026-11-05.";
        }
        if (date.isBefore(LocalDate.now())) {
            return "Date of journey cannot be in the past.";
        }
        if (source.equalsIgnoreCase(dest)) {
            return "Source and destination stations must be different.";
        }
        return null;
    }

    private void clearForm() {
        passengerField.setText("");
        trainNoField.setText("");
        trainNameField.setText("");
        classBox.setSelectedIndex(0);
        dateField.setText("");
        sourceField.setText("");
        destField.setText("");
        passengerField.requestFocusInWindow();
    }
}
