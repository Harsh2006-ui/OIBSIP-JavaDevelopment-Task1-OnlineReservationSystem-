# Online Reservation System (Java Swing + JDBC + SQLite)

## Run it
Needs JDK 11+ and Maven.

    mvn compile exec:java            # run directly
    mvn package                      # or build a single runnable jar
    java -jar target/online-reservation-1.0.jar

In IntelliJ/Eclipse/VS Code: open this folder as a Maven project and run `com.reservation.Main`.
The first run creates `reservation.db` in the folder you start from and adds demo data.

## Demo logins
- student / pass123
- admin / admin123

## Demo trains (type the number, the name fills in automatically)
12627, 12301, 12951, 12009, 12723, 22691, 12839, 12615

## Project layout
- Main.java           starts the app, creates the database
- Database.java       connection, table creation, demo data, password hashing
- ReservationDAO.java all SQL (PreparedStatement only)
- Reservation.java    booking model
- LoginFrame.java     login form
- MainFrame.java      window with Book / Cancel tabs and Logout
- BookingPanel.java   reservation form + validation + confirmation dialog
- CancelPanel.java    PNR fetch + "Are you sure?" cancellation

## Quick test
1. Log in as student / pass123 with a wrong password first to see "Access denied".
2. Book: passenger Asha, train 12627 (name appears), class 2A, date in the future as yyyy-MM-dd, Bengaluru to Chennai.
3. Copy the 10-digit PNR from the confirmation, open Cancel Ticket, Fetch, then Confirm Cancellation.
4. Fetch the same PNR again: it reports no booking found.
